/// <reference types="vite/client" />

declare const __COMMIT_HASH__: string;
declare const __COMMIT_MSG__: string;
