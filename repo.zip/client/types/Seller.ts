// Import Seller types from schema.ts as the single source of truth
export type {
  SellerProduct,
  SellerProfile,
  Order,
  SellerPayout,
} from '@/server/schema';
