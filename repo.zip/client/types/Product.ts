// Import Product type from schema.ts as the single source of truth
export type { Product } from '@/server/schema';
